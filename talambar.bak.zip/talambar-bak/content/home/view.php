<?php
namespace content\home;

class view extends \mvc\view
{

}
?>