<?php
/**
 @ In the name Of Allah
 * The base configurations of the SAMAC.
 * This file has the configurations of MySQL settings and useful core settings
 */

// ** MySQL settings - You can get this info from your web host ** //
 /** The name of the database */
 define("db_name", 'talambar');

 /** MySQL database username */
 define("db_user", 'ermile');

 /** MySQL database password */
 define("db_pass", 'Ermile@#$1233');

define('CommingSoon', true);

?>