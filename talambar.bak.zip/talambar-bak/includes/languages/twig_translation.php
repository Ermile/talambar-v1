<?php
function transtext()
{

	//---------------------avad/supervisor/projects/talambar/content/home/display.html
	echo T_("Talambar");                                                              // Line 21
	echo T_("Another cloud storage!");                                                // Line 9 Seperate
	echo T_("Indeed we respect for privacy and try to providing maximum security for your files.");// Line 9 Seperate
	echo T_("Learn more");                                                            // Line 12
	echo T_("or");                                                                    // Line 93
	echo T_("Signup");                                                                // Line 14
	echo T_("Files");                                                                 // Line 20
	echo T_("Logout");                                                                // Line 46
	echo T_("Login");                                                                 // Line 48
	echo T_("Security. Privacy. Simply.");                                            // Line 28
	echo T_("Experience our service in your language");                               // Line 72

	//------------------avad/supervisor/projects/talambar/content_cp/home/display.html
	echo T_("Home");                                                                  // Line 40

	//-------------------avad/supervisor/projects/talambar/content_cp/main/layout.html
	echo T_("Options");                                                               // Line 25 Seperate
	echo T_("Go to");                                                                 // Line 34 Seperate
	echo T_("Add New Record");                                                        // Line 39 Seperate
	echo T_("Actions");                                                               // Line 52
	echo T_("Edit this record");                                                      // Line 70
	echo T_("Edit");                                                                  // Line 71
	echo T_("Delete this record");                                                    // Line 73
	echo T_("Delete");                                                                // Line 94
	echo T_("delete record");                                                         // Line 89 Seperate
	echo T_("seriously, are you sure? There's no coming back.");                      // Line 90 Seperate
	echo T_("Cancel");                                                                // Line 92

	//---------------avad/supervisor/projects/talambar/content_files/home/display.html
	echo T_("Upload");                                                                // Line 31
	echo T_("Create new folder");                                                     // Line 34
	echo T_("Ermile is our brand");                                                   // Line 64

	//-----------------avad/supervisor/projects/talambar/includes/cls/macro/forms.html
	echo T_("Select");                                                                // Line 57

	//---------------------avad/supervisor/projects/talambar/includes/mvc/display.html
	echo T_("Home Page");                                                             // Line 43
	echo T_("Control Panel");                                                         // Line 44

}
?>