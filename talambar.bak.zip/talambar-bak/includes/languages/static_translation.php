<?php
function transtext()
{
	// add static text for detect poedit translate
	// Saloos Default data
	echo T_('Saloos');
	echo T_('saloos');
	echo T_('Another Project with Saloos');
	echo T_('Saloos is an artichokes for PHP programming!!');
	echo T_('Saloos is powerfull.');
	echo T_('insert successfully');
	echo T_('insert failed!');
	echo T_('update successfully');
	echo T_('update failed!');
	echo T_('delete successfully');
	echo T_('delete failed!');
	echo T_('id does not exist!');
	echo T_('all require fields must fill');
	echo T_('some fields must be change for update!');
	echo T_('Ermile');
	echo T_('ermile');
	echo T_('now we only support Iran!');
	echo T_('your verification code is');
	echo T_('your recovery code is');
	echo T_('you account is verified successfully');
	echo T_('thanks for using our service');
	echo T_('made in iran');
	echo T_('Iran');
	echo T_('iran');
	echo T_('submit');
	echo T_('save');
	echo T_('add new');
	echo T_('signin');
	echo T_('sign in');
	echo T_('signup');
	echo T_('sign up');
	echo T_('register');
	echo T_('create an account');
	echo T_('home');
	echo T_('Home');
	echo T_('homepage');
	echo T_('Homepage');
	echo T_('admin');
	echo T_('error in field');
	/**
	**
	**
	**
	** Your new static text that does not exist on this project! Add them manually in below lines
	**/
	echo T_('Report');



}
?>