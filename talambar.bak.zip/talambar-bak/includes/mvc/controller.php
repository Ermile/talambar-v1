<?php
namespace mvc;
use \lib\router;

class controller extends \lib\mvc\controller
{
	function _construct()
	{
		// if($this->login())
		// 	var_dump($this->login('all'));
	}
}
?>