<?php
namespace mvc;

class model extends \lib\mvc\model
{
	function _construct()
	{

	}
}
?>